#include "timepin.h"
#include "output.h"
#include "input.h"
int main()
{
	read();
	write();
}
