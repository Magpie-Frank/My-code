#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include "timepin.h"
FILE *fp;
void write()
{
	fp=fopen("accouts.xls","a+");
	double ac;
	char tip[100];
	scanf("%lf %s",&ac,tip);
	struct tm t=timepin();
	fprintf(fp,"%d.%d.%d\t%lf\t%s\n",t.tm_year+1900,t.tm_mon,t.tm_mday,ac,tip);
	fclose(fp);
}
