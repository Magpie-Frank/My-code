#include "timepin.h"
#include "output.h"
int main()
{
	write();
}
