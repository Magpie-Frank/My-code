#include<time.h>
struct tm timepin(void);
